// Copyright 2010-2013 (c) IeAT, Siemens AG, AVANTSSAR and SPaCIoS consortia.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.avantssar.aslanpp.model;

import java.util.HashMap;

public class FreshNameGenerator {

	private final HashMap<String, Integer> countersByPrefix = new HashMap<String, Integer>();
	private final IScope scope;

	protected FreshNameGenerator(IScope scope) {
		this.scope = scope;
	}

	public String getFreshName(String prefix, Class<? extends IOwned> type) {
		String freshName = prefix;
		while (scope.isNameClash(freshName, type)) {
			freshName = getNextName(prefix);
		}
		return freshName;
	}

	public String getFreshNameNumbered(String prefix, Class<? extends IOwned> type) {
		String freshName = null;
		do {
			freshName = getNextName(prefix);
		}
		while (scope.isNameClash(freshName, type));
		return freshName;
	}

	private String getNextName(String prefix) {
		Integer counter;
		if (!countersByPrefix.containsKey(prefix)) {
			counter = new Integer(1);
		}
		else {
			Integer oldCounter = countersByPrefix.get(prefix);
			counter = new Integer(oldCounter.intValue() + 1);
		}
		countersByPrefix.put(prefix, counter);
		return prefix + "_" + counter.intValue();
	}

}
