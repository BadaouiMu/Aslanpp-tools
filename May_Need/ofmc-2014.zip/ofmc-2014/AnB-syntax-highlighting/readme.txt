Syntax Highlighting for 

- Emacs: upon startup, emacs will look for a file ".emacs" in your home directory containing your settings. To define highlighting for .AnB files (and .if files), use the attached "emacs" file. (If you already have a ".emacs", you may want to just *add the contents* of the attached file.)

- Notepad++:  highlighting written by Tobias Bertelsen
Install instructions: 
1. Open the UDL-dialog by either go to "Language -> Define your launguage..."
   or "View -> User Define Dialog" (depending on version.) 
2. Click import and select this file. 
3. Restart notepad++ 
You might need to update notepad++ if it doesn't work. 

- If you have another favorite editor and can write syntax highlighting for that --- please share! 

